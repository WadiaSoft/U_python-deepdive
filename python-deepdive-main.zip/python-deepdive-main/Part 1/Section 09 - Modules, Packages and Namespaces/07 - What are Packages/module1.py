print('executing module1...')

value = 'module1 value'