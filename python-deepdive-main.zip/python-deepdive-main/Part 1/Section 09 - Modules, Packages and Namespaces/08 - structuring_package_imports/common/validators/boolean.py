# boolean.py

__all__ = ['is_boolean']


def is_boolean(arg):
    pass


def boolean_helper_1():
    pass


def boolean_helper_2():
    pass
