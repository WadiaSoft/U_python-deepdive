# module1.py

print('Running module1.py')


def hello():
    print('module1 says Hello!')